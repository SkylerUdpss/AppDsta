package com.animeninja.skylermodz;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.util.ArrayList;

public class AnimeDetailsActivity extends Activity {

    private String animeUrl;
    private TextView tvTitulo, tvProgreso;
    private ListView lvEpisodios;
    private ArrayList<String> listaNombresEpisodios = new ArrayList<>();
    private ArrayList<String> listaUrlsEpisodios = new ArrayList<>();
    private String animeId; // Clave para las SharedPreferences

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anime_details);

        animeUrl = getIntent().getStringExtra("ANIME_URL");
        // Extraer un ID simple desde la URL (ej: /anime/solo-leveling/ -> solo-leveling)
        animeId = animeUrl.replace("https://ww3.animeonline.ninja/anime/", "").replace("/", "");

        tvTitulo = findViewById(R.id.tvTituloAnime);
        tvProgreso = findViewById(R.id.tvProgresoGuardado);
        lvEpisodios = findViewById(R.id.lvEpisodios);

        mostrarProgresoGuardado();
        cargarDatosWeb();
    }

    private void mostrarProgresoGuardado() {
        SharedPreferences prefs = getSharedPreferences("AnimePrefs", MODE_PRIVATE);
        String ultimoEp = prefs.getString("last_ep_" + animeId, "Ninguno todavía");
        long ms = prefs.getLong("last_time_" + animeId, 0);
        if (ms > 0) {
            long min = (ms / 1000) / 60;
            long sec = (ms / 1000) % 60;
            tvProgreso.setText("Último visto: " + ultimoEp + " (Minuto " + min + ":" + String.format("%02d", sec) + ")");
        } else {
            tvProgreso.setText("Progreso: " + ultimoEp);
        }
    }

    private void cargarDatosWeb() {
    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                // Configuración con Headers para engañar a Cloudflare
                final Document doc = Jsoup.connect(animeUrl)
                    .userAgent(Config.USER_AGENT)
                    .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
                    .header("Accept-Language", "es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3")
                    .header("Referer", "https://www.google.com/")
                    .header("Connection", "keep-alive")
                    .timeout(15000)
                    .get();

                final String titulo = doc.select("div.data h1").text();
                Elements listaElementos = doc.select("ul.episodios li");
                
                listaNombresEpisodios.clear();
                listaUrlsEpisodios.clear();

                for (Element elemento : listaElementos) {
                    String urlEpisodio = elemento.select("a").attr("href");
                    String numEpisodio = elemento.select("div.numerando").text();
                    String nombreCompleto = "Episodio " + numEpisodio;

                    if (!urlEpisodio.isEmpty()) {
                        listaNombresEpisodios.add(nombreCompleto);
                        listaUrlsEpisodios.add(urlEpisodio);
                    }
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvTitulo.setText(titulo.isEmpty() ? "Anime Encontrado" : titulo);
                        configurarLista();
                    }
                });

            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        // Imprime el error real en consola para saber si es un 403 (Cloudflare)
                        Toast.makeText(AnimeDetailsActivity.this, "Error de Red/Cloudflare. Reintentando...", Toast.LENGTH_LONG).show();
                    }
                });
            }
        }
    }).start();
}


    private void configurarLista() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaNombresEpisodios);
        lvEpisodios.setAdapter(adapter);

        lvEpisodios.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					String epSeleccionadoUrl = listaUrlsEpisodios.get(position);
					String epNombre = listaNombresEpisodios.get(position);

					// Ir al reproductor pasando la URL del episodio para extraer sus iFrames de video
					Intent pIntent = new Intent(AnimeDetailsActivity.this, CustomPlayerActivity.class);
					pIntent.putExtra("EPISODIO_URL", epSeleccionadoUrl);
					pIntent.putExtra("ANIME_ID", animeId);
					pIntent.putExtra("EPISODIO_NOMBRE", epNombre);
					startActivity(pIntent);
				}
			});
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Recargar el progreso por si regresamos de ver un video
        mostrarProgresoGuardado();
    }
}

