package com.animeninja.skylermodz;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class SessionManagerActivity extends Activity {

    private ArrayList<SessionStorage.SessionItem> allSessions;
    private ArrayList<SessionStorage.SessionItem> filteredList;
    private ArrayAdapter<SessionStorage.SessionItem> adapter;
    
    private String currentTab = "ANIME"; 
    
    private LinearLayout containerAddSession;
    private ScrollView containerCredits; 
    private ListView lvSessions;
    private Button btnTabAnime, btnTabManga, btnTabCredits;
    private Spinner spMethods;
    private EditText etSessionName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_session_manager);

        etSessionName = (EditText) findViewById(R.id.et_session_name);
        Button btnAddSession = (Button) findViewById(R.id.btn_add_session);
        lvSessions = (ListView) findViewById(R.id.lv_sessions);
        spMethods = (Spinner) findViewById(R.id.sp_methods);
        
        containerAddSession = (LinearLayout) findViewById(R.id.container_add_session);
        containerCredits = (ScrollView) findViewById(R.id.container_credits); 
        
        btnTabAnime = (Button) findViewById(R.id.btn_tab_anime);
        btnTabManga = (Button) findViewById(R.id.btn_tab_manga);
        btnTabCredits = (Button) findViewById(R.id.btn_tab_credits);

        allSessions = SessionStorage.loadSessions(this);
        filteredList = new ArrayList<SessionStorage.SessionItem>();

        adapter = new ArrayAdapter<SessionStorage.SessionItem>(this, android.R.layout.simple_list_item_2, filteredList) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = convertView;
                if (view == null) {
                    view = LayoutInflater.from(getContext()).inflate(android.R.layout.simple_list_item_2, parent, false);
                }
                TextView tv1 = (TextView) view.findViewById(android.R.id.text1);
                TextView tv2 = (TextView) view.findViewById(android.R.id.text2);
                
                SessionStorage.SessionItem item = filteredList.get(position);
                
                if (tv1 != null) {
                    tv1.setText(item.name);
                    tv1.setTextColor(Color.WHITE);
                    tv1.setTextSize(17);
                }
                if (tv2 != null) {
                    tv2.setText("Plataforma: " + item.method);
                    tv2.setTextColor(Color.parseColor("#A8A8A8"));
                    tv2.setTextSize(12);
                }
                view.setPadding(32, 28, 32, 28);
                return view;
            }
        };
        lvSessions.setAdapter(adapter);

        btnTabAnime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchTab("ANIME");
            }
        });

        btnTabManga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchTab("MANGA");
            }
        });

        btnTabCredits.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchTab("CREDITS");
            }
        });

        switchTab("ANIME");

        lvSessions.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                SessionStorage.SessionItem selected = filteredList.get(position);
                Intent intent = new Intent(SessionManagerActivity.this, MainActivity.class);
                intent.putExtra("SESSION_NAME", selected.name);
                intent.putExtra("SESSION_METHOD", selected.method);
                intent.putExtra("SESSION_TYPE", selected.type);
                startActivity(intent);
            }
        });

        lvSessions.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Toast.makeText(SessionManagerActivity.this, "Protegido por el sistema", Toast.LENGTH_SHORT).show();
                    return true;
                }
                SessionStorage.SessionItem removed = filteredList.get(position);
                
                for (int i = 0; i < allSessions.size(); i++) {
                    SessionStorage.SessionItem current = allSessions.get(i);
                    if (current.name.equals(removed.name) && current.type.equals(removed.type)) {
                        allSessions.remove(i);
                        break;
                    }
                }
                
                filteredList.remove(position);
                SessionStorage.saveSessions(SessionManagerActivity.this, allSessions);
                adapter.notifyDataSetChanged();
                Toast.makeText(SessionManagerActivity.this, "Eliminado con éxito", Toast.LENGTH_SHORT).show();
                return true;
            }
        });

        btnAddSession.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etSessionName.getText().toString().trim();
                String method = "AnimeNinja";
                if (spMethods != null && spMethods.getSelectedItem() != null) {
                    method = spMethods.getSelectedItem().toString();
                }
                
                if (name.isEmpty()) {
                    Toast.makeText(SessionManagerActivity.this, "Ingresa un nombre válido", Toast.LENGTH_SHORT).show();
                    return;
                }
                
                for (SessionStorage.SessionItem item : allSessions) {
                    if (item.name.equalsIgnoreCase(name) && item.type.equals(currentTab)) {
                        Toast.makeText(SessionManagerActivity.this, "Ya existe esta sesión", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                SessionStorage.SessionItem newItem = new SessionStorage.SessionItem(name, method, currentTab);
                allSessions.add(newItem);
                SessionStorage.saveSessions(SessionManagerActivity.this, allSessions);
                etSessionName.setText("");
                updateFilter();
            }
        });
    }

    private void switchTab(String tab) {
        currentTab = tab;
        
        btnTabAnime.setBackgroundColor(tab.equals("ANIME") ? Color.parseColor("#2196F3") : Color.parseColor("#222222"));
        btnTabManga.setBackgroundColor(tab.equals("MANGA") ? Color.parseColor("#E91E63") : Color.parseColor("#222222"));
        btnTabCredits.setBackgroundColor(tab.equals("CREDITS") ? Color.parseColor("#4CAF50") : Color.parseColor("#222222"));

        if (tab.equals("CREDITS")) {
            containerAddSession.setVisibility(View.GONE);
            lvSessions.setVisibility(View.GONE);
            containerCredits.setVisibility(View.VISIBLE);
        } else {
            containerCredits.setVisibility(View.GONE);
            containerAddSession.setVisibility(View.VISIBLE);
            lvSessions.setVisibility(View.VISIBLE);
            
            String[] models;
            if (tab.equals("ANIME")) {
                models = new String[]{"AnimeNinja", "AnimeFlv", "Fiuzidragon"};
            } else {
                models = new String[]{"NovelCool", "GoodNovel", "LectorMangass", "Webtoons", "YupManga", "MangaDex", "VisorManga"};
            }
            
            ArrayAdapter<String> spinAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, models);
            spinAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spMethods.setAdapter(spinAdapter);
            
            updateFilter();
        }
    }

    private void updateFilter() {
        filteredList.clear();
        for (SessionStorage.SessionItem item : allSessions) {
            if (item.type.equals(currentTab)) {
                filteredList.add(item);
            }
        }
        adapter.notifyDataSetChanged();
    }
}
