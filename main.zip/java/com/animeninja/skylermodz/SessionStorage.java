package com.animeninja.skylermodz;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class SessionStorage {

    private static final String FILE_NAME = "app_sessions.json";

    public static class SessionItem {
        public String name;
        public String method;
        public String type; // "ANIME" o "MANGA"

        public SessionItem(String name, String method, String type) {
            this.name = name;
            this.method = method;
            this.type = type;
        }
    }

    // Carga todas las sesiones desde el archivo JSON
    public static ArrayList<SessionItem> loadSessions(Context context) {
        ArrayList<SessionItem> list = new ArrayList<>();
        File file = new File(context.getFilesDir(), FILE_NAME);
        
        // ---MIGRACIÓN AUTOMÁTICA DESDE SHAREDPREFERENCES---
        if (!file.exists()) {
            checkAndMigrateOldPrefs(context);
        }

        if (!file.exists()) {
            // Valores por defecto iniciales si no existe nada anterior
            list.add(new SessionItem("Sesión Principal (Default)", "AnimeNinja", "ANIME"));
            list.add(new SessionItem("Lector Principal (Default)", "MangaNinja", "MANGA"));
            saveSessions(context, list);
            return list;
        }

        try {
            FileInputStream fis = new FileInputStream(file);
            byte[] data = new byte[(int) file.length()];
            fis.read(data);
            fis.close();
            
            JSONArray jsonArray = new JSONArray(new String(data, "UTF-8"));
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);
                list.add(new SessionItem(
                    obj.optString("name", "Unknown"),
                    obj.optString("method", "AnimeNinja"),
                    obj.optString("type", "ANIME")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Guarda la lista completa de sesiones en formato JSON masivo
    public static void saveSessions(Context context, ArrayList<SessionItem> list) {
        try {
            JSONArray jsonArray = new JSONArray();
            for (SessionItem item : list) {
                JSONObject obj = new JSONObject();
                obj.put("name", item.name);
                obj.put("method", item.method);
                obj.put("type", item.type);
                jsonArray.put(obj);
            }
            
            File file = new File(context.getFilesDir(), FILE_NAME);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(jsonArray.toString().getBytes("UTF-8"));
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Lee el SharedPreferences viejo y lo convierte al nuevo formato JSON de forma transparente
    private static void checkAndMigrateOldPrefs(Context context) {
        SharedPreferences oldPrefs = context.getSharedPreferences("AnimeNinjaSessions", Context.MODE_PRIVATE);
        Set<String> savedSet = oldPrefs.getStringSet("session_set", null);
        
        if (savedSet != null && !savedSet.isEmpty()) {
            ArrayList<SessionItem> migratedList = new ArrayList<>();
            for (String rawData : savedSet) {
                String name = rawData;
                String method = "AnimeNinja";
                if (rawData.contains("|")) {
                    String[] parts = rawData.split("\\|");
                    name = parts[0];
                    if (parts.length > 1) method = parts[1];
                }
                migratedList.add(new SessionItem(name, method, "ANIME"));
            }
            // Agregamos por defecto una de manga para que inicien con el nuevo modo instalado
            migratedList.add(new SessionItem("Lector Principal (Default)", "VisorManga", "MANGA"));
            saveSessions(context, migratedList);
            
            // Opcional: Limpiar preferencias viejas para evitar re-migraciones
            oldPrefs.edit().remove("session_set").apply();
        }
    }
}
