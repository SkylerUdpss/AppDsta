package com.animeninja.skylermodz;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import java.util.HashMap;
import java.util.Map;

public class CustomPlayerActivity extends Activity {

    private WebView webViewContenedor;
    private ProgressBar progressBar;
    private String episodioUrl; // Recibe la URL tipo: https://ww3.animeonline.ninja/online/...

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_player);

        episodioUrl = getIntent().getStringExtra("EPISODIO_URL");
        webViewContenedor = findViewById(R.id.webViewContenedor);
        progressBar = findViewById(R.id.pbCargandoVideo);

        configurarWebViewNavegador();
    }

    private void configurarWebViewNavegador() {
        WebSettings settings = webViewContenedor.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true); // Crucial para reproductores modernos
        settings.setMediaPlaybackRequiresUserGesture(false); // Auto-play de video
        
        // Forzamos el User-Agent idéntico al de Jsoup para mantener consistencia con Cloudflare
        settings.setUserAgentString(Config.USER_AGENT);

        // Habilitar Cookies por si Cloudflare genera un token de sesión
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webViewContenedor, true);

        webViewContenedor.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                
                // Si la página intenta abrir ventanas emergentes (Ads de redirección), las bloqueamos
                if (!url.contains("animeonline.ninja")) {
                    return true; 
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);

                // MODIFICACIÓN DE LA WEB (Inyección CSS/JS)
                // Ocultamos el header, los comentarios, el footer y los laterales de la web original.
                // Ajustamos el contenedor del reproductor para que ocupe toda tu app.
                String javascriptLimpiador = "javascript:(function() { " +
                        "document.getElementsByTagName('header')[0].style.display='none'; " +
                        "document.getElementsByClassName('sidebar')[0].style.display='none'; " +
                        "document.getElementById('comments').style.display='none'; " +
                        "document.getElementsByTagName('footer')[0].style.display='none'; " +
                        "var contenido = document.getElementsByClassName('content')[0]; " +
                        "if(contenido) { contenido.style.width='100%'; contenido.style.padding='0'; } " +
                        "var player = document.getElementById('playvideodoo'); " +
                        "if(player) { player.style.height='100vh'; player.style.width='100vw'; }" +
                        "})()";

                webViewContenedor.loadUrl(javascriptLimpiador);
            }
        });

        // Preparamos los Headers de manera manual para la petición inicial
        Map<String, String> headers = new HashMap<>();
        headers.put("User-Agent", Config.USER_AGENT);
        headers.put("Accept-Language", "es-ES,es;q=0.9");
        headers.put("Referer", "https://www.google.com/");

        // Cargamos la URL directa con los parámetros de bypass
        webViewContenedor.loadUrl(episodioUrl, headers);
    }

    @Override
    public void onBackPressed() {
        if (webViewContenedor.canGoBack()) {
            webViewContenedor.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (webViewContenedor != null) {
            webViewContenedor.destroy();
        }
    }
}
