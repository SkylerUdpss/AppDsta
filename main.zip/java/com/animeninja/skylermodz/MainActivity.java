package com.animeninja.skylermodz;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.File;

public class MainActivity extends android.app.Activity {

    private WebView webView;
    private FrameLayout customViewContainer;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private View mCustomView;
    
    private String TARGET_URL = "https://ww3.animeonline.ninja/online/";
    private String currentSessionName = "Default"; 
    private String sessionMethod = "AnimeNinja"; 
    private String sessionType = "ANIME"; // Parámetro: ANIME o MANGA

        // ==========================================
    // CÓDIGO TEMPORAL PARA OBTENER TUS DATOS (Suelito y sin errores)
    // ==========================================
    @Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    // Verificar la firma
    if (!SignatureVerifier.verify(this)) {
        Toast.makeText(this, "Aplicación modificada", Toast.LENGTH_LONG).show();
        finish();
        return;
    }

    requestWindowFeature(Window.FEATURE_NO_TITLE);

    getWindow().setFlags(
        WindowManager.LayoutParams.FLAG_FULLSCREEN,
        WindowManager.LayoutParams.FLAG_FULLSCREEN
    );

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
        getWindow().setNavigationBarColor(Color.parseColor("#121212"));   // Resto de tu código...

        }
    
    // ... el resto de tu código sigue normal abajo ...


        // --- DETECTOR DE INTENTOS (SESIÓN, MÉTODO Y TIPO JSON) ---
        if (getIntent() != null) {
            if (getIntent().hasExtra("SESSION_NAME")) {
                currentSessionName = getIntent().getStringExtra("SESSION_NAME");
            }
            if (getIntent().hasExtra("SESSION_METHOD")) {
                sessionMethod = getIntent().getStringExtra("SESSION_METHOD");
            }
            if (getIntent().hasExtra("SESSION_TYPE")) {
                sessionType = getIntent().getStringExtra("SESSION_TYPE");
            }
        }

        // --- SELECTOR INTELIGENTE DE URL INICIAL ---
        if ("MANGA".equalsIgnoreCase(sessionType)) {
            if ("MangaDex".equalsIgnoreCase(sessionMethod)) {
                TARGET_URL = "https://mangadex.org/";
            } else if ("VisorManga".equalsIgnoreCase(sessionMethod)) {
                TARGET_URL = "https://visormanga.com/";
            } else if ("NovelCool".equalsIgnoreCase(sessionMethod)) {
                TARGET_URL = "https://es.novelcool.com/category/Manga.html";
            } else if ("GoodNovel".equalsIgnoreCase(sessionMethod)) {
                TARGET_URL = "https://www.goodnovel.com/qa/es/t_lector-de-manga";
            } else if ("LectorMangass".equalsIgnoreCase(sessionMethod)) {
                TARGET_URL = "https://lectormangass.net/";
            } else if ("Webtoons".equalsIgnoreCase(sessionMethod)) {
                TARGET_URL = "https://m.webtoons.com/es/";
            } else if ("YupManga".equalsIgnoreCase(sessionMethod)) {
                TARGET_URL = "https://www.yupmanga.com/";
            } else {
                TARGET_URL = "https://visormanga.com/"; // VisorManga por defecto en pestaña Manga
            }
        } else {
            // Homologación de dominios para Anime
            if ("AnimeFlv v1".equalsIgnoreCase(sessionMethod) || "AnimeFlv".equalsIgnoreCase(sessionMethod)) {
                TARGET_URL = "https://animeflv.or.at/";
            } else if ("Fiuzidragon".equalsIgnoreCase(sessionMethod) || "Fruzidragon".equalsIgnoreCase(sessionMethod)) {
                TARGET_URL = "https://www.fiuzidragon.com/";
            } else {
                TARGET_URL = "https://ww3.animeonline.ninja/online/";
            }
        }

        setContentView(R.layout.activity_main);

        // =========================================================================
        //  CORRECCIÓN: Se infla "activity_session_manager" para buscar los elementos allí
        // =========================================================================
        LayoutInflater inflater = LayoutInflater.from(this);
        View sessionManagerView = inflater.inflate(R.layout.activity_session_manager, null);

        final Button btnTabAnime = sessionManagerView.findViewById(R.id.btn_tab_anime);
        final Button btnTabManga = sessionManagerView.findViewById(R.id.btn_tab_manga);
        final Button btnTabCredits = sessionManagerView.findViewById(R.id.btn_tab_credits);

        final LinearLayout containerAddSession = sessionManagerView.findViewById(R.id.container_add_session);
        final ListView lvSessions = sessionManagerView.findViewById(R.id.lv_sessions);
        final ScrollView containerCredits = sessionManagerView.findViewById(R.id.container_credits);

        final Button btnAddSession = sessionManagerView.findViewById(R.id.btn_add_session);
        Button btnSupportAds = sessionManagerView.findViewById(R.id.btn_support_ads);
        Button btnLinkYoutube = sessionManagerView.findViewById(R.id.btn_link_youtube);
        Button btnLinkDiscord = sessionManagerView.findViewById(R.id.btn_link_discord);

        View themeBlue = sessionManagerView.findViewById(R.id.theme_blue);
        View themeRed = sessionManagerView.findViewById(R.id.theme_red);
        View themePurple = sessionManagerView.findViewById(R.id.theme_purple);
        View themeGreen = sessionManagerView.findViewById(R.id.theme_green);

        // Control de visibilidad de las pestañas
        if (btnTabAnime != null && btnTabManga != null && btnTabCredits != null) {
            btnTabAnime.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (containerAddSession != null) containerAddSession.setVisibility(View.VISIBLE);
                    if (lvSessions != null) lvSessions.setVisibility(View.VISIBLE);
                    if (containerCredits != null) containerCredits.setVisibility(View.GONE);
                    sessionType = "ANIME";
                }
            });

            btnTabManga.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (containerAddSession != null) containerAddSession.setVisibility(View.VISIBLE);
                    if (lvSessions != null) lvSessions.setVisibility(View.VISIBLE);
                    if (containerCredits != null) containerCredits.setVisibility(View.GONE);
                    sessionType = "MANGA";
                }
            });

            btnTabCredits.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (containerAddSession != null) containerAddSession.setVisibility(View.GONE);
                    if (lvSessions != null) lvSessions.setVisibility(View.GONE);
                    if (containerCredits != null) containerCredits.setVisibility(View.VISIBLE);
                }
            });
        }

        // ==========================================
        //  MODIFICACIÓN: Cargar URLs en el WebView
        // ==========================================
        if (btnSupportAds != null) {
            btnSupportAds.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (webView != null) {
                        webView.loadUrl("https://lootdest.org/Ads123");
                        Toast.makeText(MainActivity.this, "¡Cargando apoyo! Gracias por el aguante ⚡", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        if (btnLinkYoutube != null) {
            btnLinkYoutube.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (webView != null) {
                        webView.loadUrl("https://www.youtube.com/@SkylerModz");
                    }
                }
            });
        }

        if (btnLinkDiscord != null) {
            btnLinkDiscord.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (webView != null) {
                        webView.loadUrl("https://discord.gg/vkNqGQtWg9");
                    }
                }
            });
        }


        // Lógica persistente para cambio de colores (Temas)
        final SharedPreferences themePrefs = getSharedPreferences("AppThemePrefs", MODE_PRIVATE);
        int savedColor = themePrefs.getInt("accent_color", Color.parseColor("#2196F3"));

        if (btnTabAnime != null && btnAddSession != null) {
            btnTabAnime.setBackgroundTintList(android.content.res.ColorStateList.valueOf(savedColor));
            btnAddSession.setBackgroundTintList(android.content.res.ColorStateList.valueOf(savedColor));
        }

        if (themeBlue != null && themeRed != null && themePurple != null && themeGreen != null) {
            themeBlue.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int c = Color.parseColor("#2196F3");
                    themePrefs.edit().putInt("accent_color", c).apply();
                    if(btnTabAnime != null) btnTabAnime.setBackgroundTintList(android.content.res.ColorStateList.valueOf(c));
                    if(btnAddSession != null) btnAddSession.setBackgroundTintList(android.content.res.ColorStateList.valueOf(c));
                }
            });
            themeRed.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int c = Color.parseColor("#E91E63");
                    themePrefs.edit().putInt("accent_color", c).apply();
                    if(btnTabAnime != null) btnTabAnime.setBackgroundTintList(android.content.res.ColorStateList.valueOf(c));
                    if(btnAddSession != null) btnAddSession.setBackgroundTintList(android.content.res.ColorStateList.valueOf(c));
                }
            });
            themePurple.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int c = Color.parseColor("#9C27B0");
                    themePrefs.edit().putInt("accent_color", c).apply();
                    if(btnTabAnime != null) btnTabAnime.setBackgroundTintList(android.content.res.ColorStateList.valueOf(c));
                    if(btnAddSession != null) btnAddSession.setBackgroundTintList(android.content.res.ColorStateList.valueOf(c));
                }
            });
            themeGreen.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int c = Color.parseColor("#4CAF50");
                    themePrefs.edit().putInt("accent_color", c).apply();
                    if(btnTabAnime != null) btnTabAnime.setBackgroundTintList(android.content.res.ColorStateList.valueOf(c));
                    if(btnAddSession != null) btnAddSession.setBackgroundTintList(android.content.res.ColorStateList.valueOf(c));
                }
            });
        }
        // ==========================================

        webView = findViewById(R.id.webview);
        customViewContainer = (FrameLayout) findViewById(R.id.webview).getParent();

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
        hideSystemUI();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        
        final String safeSessionDir = "session_" + currentSessionName.replaceAll("[^a-zA-Z0-9]", "_");
        File databaseDir = this.getDir(safeSessionDir, MODE_PRIVATE);
        
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            settings.setDatabasePath(databaseDir.getPath());
        }
        
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMediaPlaybackRequiresUserGesture(false); 
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);

        settings.setUseWideViewPort(true);       
        settings.setLoadWithOverviewMode(true);   
        settings.setSupportZoom(false);           
        settings.setBuiltInZoomControls(false);

        String userAgent = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36";
        settings.setUserAgentString(userAgent);

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.flush();
        }

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public Bitmap getDefaultVideoPoster() {
                return Bitmap.createBitmap(10, 10, Bitmap.Config.ARGB_8888);
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (mCustomView != null) {
                    onHideCustomView();
                    return;
                }
                mCustomView = view;
                customViewCallback = callback;
                webView.setVisibility(View.GONE);
                customViewContainer.addView(mCustomView, new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, 
                        FrameLayout.LayoutParams.MATCH_PARENT));
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                hideSystemUI(); 
            }

            @Override
            public void onHideCustomView() {
                if (mCustomView == null) return;
                webView.setVisibility(View.VISIBLE);
                customViewContainer.removeView(mCustomView);
                mCustomView = null;
                if (customViewCallback != null) customViewCallback.onCustomViewHidden();
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
                hideSystemUI(); 
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                
                // Permitir que cargue Youtube, Discord o lootdest internamente si se pulsan los botones
                if (url.contains("youtube.com") || url.contains("youtu.be") || 
                    url.contains("discord") || url.contains("lootdest.org")) {
                    return false;
                }

                // Bloqueo directo de redirecciones que contengan los TLDs maliciosos reportados
                if (url.contains(".cfd") || url.contains(".cyou")) {
                    return true;
                }

                // Permitir navegación interna fluida sin bloqueos
                if (url.contains("animeonline.ninja") || url.contains("animeflv") || 
                    url.contains("fiuzidragon.com") || url.contains("fruzidragon") ||
                    url.contains("mangadex.org") || url.contains("lectortmo.com") || url.contains("visormanga.com") ||
                    url.contains("novelcool.com") || url.contains("goodnovel.com") || url.contains("lectormangass.net") ||
                    url.contains("webtoons.com") || url.contains("yupmanga.com") ||
                    url.contains("jkfembed") || url.contains("fembed") || url.contains("ok.ru") || 
                    url.contains("streamwish") || url.contains("filemoon") || url.contains("voe.sx") || url.contains("voodo")) {
                    return false; 
                }
                return true; 
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString().toLowerCase();
                
                if (url.contains("/uploads/") || url.contains("/wp-content/") || url.matches(".*\\.(jpg|jpeg|png|webp|gif).*")) {
                    return super.shouldInterceptRequest(view, request);
                }
                
                // --- FILTRO AMPLIADO CONTRA POPUPS AGRESIVOS DE VISORMANGA ---
                if (url.contains("amd-cdn-1") || 
                    url.contains("agl003.com") || 
                    url.contains("chillbet") || 
                    url.contains("doubleclick") || 
                    url.contains("popads") || 
                    url.contains("adsterra") || 
                    url.contains("onclickads") || 
                    url.contains("exoclick") || 
                    url.contains("yandex") || 
                    url.contains("/ads/") || 
                    url.contains("juicyads") ||
                    url.contains("asg.voodo") || 
                    url.contains("adblock") || 
                    url.contains("adskeeper") || 
                    url.contains("mgid.com") ||   
                    url.contains("popcash") ||    
                    url.contains("video-ad") ||
                    url.contains(".cfd") ||       
                    url.contains(".cyou") ||      
                    url.contains("/sbx/") ||      
                    url.contains("/mtn/") ||      
                    url.contains("/cuid/") ||     
                    url.endsWith(".xml")) { 
                    
                    return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream("".getBytes()));
                }
                
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    CookieManager.getInstance().flush();
                }

                // Evitamos guardar temporalmente URLs externas de soporte como la última guardada de la sesión
                if (!url.contains("youtube.com") && !url.contains("discord") && !url.contains("lootdest.org")) {
                    getSharedPreferences("AnimeNinjaUrls", MODE_PRIVATE)
                            .edit()
                            .putString("last_url_" + safeSessionDir, url)
                            .apply();
                }
                
                String jsInjected;

                // --- FILTRO EXCLUSIVO PARA MANGAS ---
                if ("MANGA".equalsIgnoreCase(sessionType)) {
                    jsInjected = "javascript:(function() { " +
                            "window.open = function() { return null; }; " +
                            "window.adblock = false; window.adblock2 = false; window.premium = true; " +
                            "window.onbeforeunload = null; " +
                            "Object.defineProperty(window, 'onbeforeunload', { get: function() { return null; }, set: function() {} }); " +

                            "var sessionPrefix = '" + safeSessionDir + "_'; " +
                            "if(!window.sessionIsolated){ " +
                            "   var _setItem = localStorage.setItem; " +
                            "   var _getItem = localStorage.getItem; " +
                            "   localStorage.setItem = function(key, val){ return _setItem.call(localStorage, sessionPrefix + key, val); }; " +
                            "   localStorage.getItem = function(key){ return _getItem.call(localStorage, sessionPrefix + key); }; " +
                            "   window.sessionIsolated = true; " +
                            "} " +
                            
                            "var preventClicks = function(e) { " +
                            "   if (e.target.tagName !== 'IMG' && e.target.tagName !== 'A' && e.target.tagName !== 'BUTTON' && e.target.tagName !== 'SELECT' && e.target.tagName !== 'OPTION') { " +
                            "       e.stopPropagation(); " +
                            "   } " +
                            "}; " +
                            "document.addEventListener('click', preventClicks, true); " +
                            "document.addEventListener('mousedown', preventClicks, true); " +
                            
                            "var mangaSelectors = ['.ads', '.ads-banner', '.floating-ad', '#disqus_thread', 'iframe[src*=\"ads\"]', '.top-banner', 'footer', 'header', '#header', '[class*=\"ads\"]', '[id*=\"ad\"]', '.adsbygoogle', 'iframe', 'video', '.video-container']; " +
                            "mangaSelectors.forEach(function(sel) { " +
                            "   var elements = document.querySelectorAll(sel); " +
                            "   elements.forEach(function(el) { el.remove(); }); " +
                            "}); " +
                            
                            "var badOverlays = document.querySelectorAll('div[style*=\"z-index\"], div[class*=\"overlay\"]'); " +
                            "badOverlays.forEach(function(el) { " +
                            "   if(el.innerHTML === '' || el.offsetHeight > window.innerHeight) { el.remove(); } " +
                            "}); " +

                            "document.body.style.backgroundColor = '#0F0F14'; " +
                            "document.body.style.margin = '0'; " +
                            "document.body.style.padding = '0'; " +
                            "var imgs = document.querySelectorAll('img'); " +
                            "imgs.forEach(function(img) { " +
                            "   img.style.maxWidth = '100%'; " +
                            "   img.style.height = 'auto'; " +
                            "}); " +
                            "})()";
                } 
                // --- FILTROS DE ANIME ---
                else {
                    if ("Fiuzidragon".equalsIgnoreCase(sessionMethod) || "Fruzidragon".equalsIgnoreCase(sessionMethod)) {
                        jsInjected = "javascript:(function() { " +
                                "window.adblock = false; window.adblock2 = false; window.premium = true; " +
                                "window.open = function() { return null; }; " +
                                
                                "var sessionPrefix = '" + safeSessionDir + "_'; " +
                                "if(!window.sessionIsolated){ " +
                                "   var _setItem = localStorage.setItem; " +
                                "   var _getItem = localStorage.getItem; " +
                                "   localStorage.setItem = function(key, val){ return _setItem.call(localStorage, sessionPrefix + key, val); }; " +
                                "   localStorage.getItem = function(key){ return _getItem.call(localStorage, sessionPrefix + key); }; " +
                                "   window.sessionIsolated = true; " +
                                "} " +
                                
                                "var elementsToHide = ['.ads', '.ads-reciente', '.publicidad', 'iframe[src*=\"ads\"]', '#list-server-more', '.banner-top']; " +
                                "elementsToHide.forEach(function(selector) { " +
                                "   var els = document.querySelectorAll(selector); " +
                                "   els.forEach(function(el) { el.style.display='none'; }); " +
                                "}); " +
                                
                                "var badOverlays = document.querySelectorAll('div[style*=\"z-index\"], div[class*=\"overlay\"]'); " +
                                "badOverlays.forEach(function(el) { " +
                                "   if(el.innerHTML === '' || el.offsetHeight > window.innerHeight) { el.remove(); } " +
                                "}); " +
                                
                                "document.body.style.backgroundColor = '#121212'; " +
                                "})()";
                    } 
                    else {
                        String selectors = "AnimeFlv".equalsIgnoreCase(sessionMethod) ? 
                                "['header', 'footer', '.Sidebar', '.Banner', '.Ads', '#mdlAdblock']" : 
                                "['footer', '#sidebar', '.ads', '.publicidad', '.widget', '.top-menu', '#top-nav', '.logo', '.header-banner']";
                        
                        jsInjected = "javascript:(function() { " +
                                "window.open = function() { return null; }; " +
                                "window.adblock = false; window.adblock2 = false; window.premium = true; " +
                                
                                "var sessionPrefix = '" + safeSessionDir + "_'; " +
                                "if(!window.sessionIsolated){ " +
                                "   var _setItem = localStorage.setItem; " +
                                "   var _getItem = localStorage.getItem; " +
                                "   localStorage.setItem = function(key, val){ return _setItem.call(localStorage, sessionPrefix + key, val); }; " +
                                "   localStorage.getItem = function(key){ return _getItem.call(localStorage, sessionPrefix + key); }; " +
                                "   window.sessionIsolated = true; " +
                                "} " +

                                "var elementsToHide = " + selectors + "; " +
                                "elementsToHide.forEach(function(selector) { " +
                                "   var els = document.querySelectorAll(selector); " +
                                "   els.forEach(function(el) { el.style.display='none'; }); " +
                                "}); " +
                                
                                "var searchContainer = document.querySelector('.search-form') || document.querySelector('#searchform') || document.querySelector('.search-wrap') || document.querySelector('.Search'); " +
                                "if(searchContainer) { " +
                                "   searchContainer.style.setProperty('display', 'block', 'important'); " +
                                "   searchContainer.style.setProperty('visibility', 'visible', 'important'); " +
                                "   searchContainer.style.margin = '10px auto'; " +
                                "   searchContainer.style.padding = '5px'; " +
                                "   searchContainer.style.maxWidth = '90%'; " +
                                "}" +
                                "document.body.style.padding = '0'; document.body.style.margin = '0'; document.body.style.backgroundColor = '#121212'; document.body.style.width = '100%'; " +
                                "var mainContainer = document.querySelector('#main-content') || document.querySelector('.site-content') || document.querySelector('#container') || document.querySelector('.Wrapper'); " +
                                "if(mainContainer) { " +
                                "   mainContainer.style.width = '100%'; mainContainer.style.padding = '4px'; mainContainer.style.margin = '0'; " +
                                "} " +
                                "})()";
                    }
                }
                
                view.loadUrl(jsInjected);
            }
        });

        String savedUrl = getSharedPreferences("AnimeNinjaUrls", MODE_PRIVATE)
                .getString("last_url_" + safeSessionDir, TARGET_URL);

        boolean isValidUrl = savedUrl != null && (
                savedUrl.contains("animeonline.ninja") || 
                savedUrl.contains("animeflv") || 
                savedUrl.contains("fiuzidragon") || 
                savedUrl.contains("fruzidragon") ||
                savedUrl.contains("mangadex") || 
                savedUrl.contains("lectortmo") ||
                savedUrl.contains("visormanga") ||
                savedUrl.contains("novelcool") ||
                savedUrl.contains("goodnovel") ||
                savedUrl.contains("lectormangass") ||
                savedUrl.contains("webtoons") ||
                savedUrl.contains("yupmanga")
        );
        
        if (!isValidUrl) {
            savedUrl = TARGET_URL;
        }

        webView.loadUrl(savedUrl);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().flush(); 
        }
    }

    private void hideSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION 
                    | View.SYSTEM_UI_FLAG_FULLSCREEN    
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY); 
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI(); 
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        hideSystemUI();
    }

    @Override
    public void onBackPressed() {
        if (mCustomView != null) {
            webView.getWebChromeClient().onHideCustomView();
        } else if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
