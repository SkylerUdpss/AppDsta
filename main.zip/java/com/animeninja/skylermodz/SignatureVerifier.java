package com.animeninja.skylermodz;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;

import java.security.MessageDigest;

public class SignatureVerifier {

    private static final String EXPECTED_SHA256 =
            "a40da80a59d170caa950cf15c18c454d47a39b26989d8b640ecd745ba71bf5dc";

    public static boolean verify(Context context) {
        try {
            PackageInfo packageInfo;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                packageInfo = context.getPackageManager().getPackageInfo(
                        context.getPackageName(),
                        PackageManager.GET_SIGNING_CERTIFICATES
                );

                Signature[] signatures = packageInfo.signingInfo.getApkContentsSigners();

                for (Signature sig : signatures) {
                    if (EXPECTED_SHA256.equalsIgnoreCase(sha256(sig.toByteArray()))) {
                        return true;
                    }
                }

            } else {
                packageInfo = context.getPackageManager().getPackageInfo(
                        context.getPackageName(),
                        PackageManager.GET_SIGNATURES
                );

                for (Signature sig : packageInfo.signatures) {
                    if (EXPECTED_SHA256.equalsIgnoreCase(sha256(sig.toByteArray()))) {
                        return true;
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    private static String sha256(byte[] data) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] digest = md.digest(data);

        StringBuilder sb = new StringBuilder();
        for (byte b : digest) {
            sb.append(String.format("%02x", b));
        }

        return sb.toString();
    }
}